#!/bin/bash

check_file_exists () {
	file=$1
	if [ -e $file ]; then
		exists=true
	else
		printf "%s doesn't exist\n" $file
		exists=false
		$2
	fi
}
check_dir_exists () {
	file=$1
	if [ -d $file ]; then
		exists=true
	else
		printf "%s doesn't exist\n" $file
		exists=false
		$2
	fi
}
set -e

if [ "$EUID" -ne 0 ]
  then echo "The script has to be run as root."
  exit
fi

BIN_DIR=${BIN_DIR:-/usr/local/bin/}

scriptdir=$(pwd)
cd ..
cd ..
userhome=$(pwd)
check_dir_exists $HOME/.config
if $exists; then
	printf "root users .config directory already exists"
else
	echo "creating rice directory for root"
	mkdir $HOME/.config
fi
check_dir_exists $userhome/.config
if $exists; then
	printf "your users .config directory already exists"
else
	echo "creating rice directory for user"
	mkdir .config/htop
	cp deploygentoo-master/aliasrc .config/
	cp deploygentoo-master/htoprc .config/htop
fi
cd $scriptdir

checkinstdir() {
if [ -d $1 ]; then
	echo "$1 ok"
else
	echo "$1 is missing"
	exit -1
fi
}

echo "Checking directories"
checkinstdir $BIN_DIR
#check_file_exists $HOME/.bashrc
echo "Adding Dots to root home"
cp -f dots/.rootbashrc /$HOME/.bashrc
cp -f dots/.vimrc $HOME
cp -f dots/.xinitrc $HOME
cp -f dots/.Xresources $HOME
chmod +x dots/.setres.sh
cp -f dots/.setres.sh $HOME

echo "Adding Dots to user home"
cp -f dots/.bashrc $userhome
cp -f dots/.vimrc $userhome
cp -f dots/.xinitrc $userhome
cp -f dots/.Xresources $userhome
chmod +x dots/.setres.sh
cp -f dots/.setres.sh $userhome

cp -rf dwm $HOME/.config
cp -rf dmenu $HOME/.config
cp -rf slstatus $HOME/.config
cp -rf st $HOME/.config

cd $HOME/.config/dwm
make clean install
echo "installed dwm"
cd $HOME/.config/dmenu
make clean install
echo "installed dmenu"
cd $HOME/.config/slstatus
make clean install
echo "installed slstatus"
cd $HOME/.config/st
make clean install
echo "installed st"

chmod +x $userhome/deploygentoo-master/finalize.sh
sh $userhome/deploygentoo-master/finalize.sh
echo "xorg can now be run as a non root user, and ALSA works now"

fc-cache -fv

echo "Install finished. Add software to .xinitrc to launch the DE with startx,
or copy the provided .xinitrc file to your home directory (backup the old one!)"
