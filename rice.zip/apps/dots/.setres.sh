xrandr -s 1920x1080
